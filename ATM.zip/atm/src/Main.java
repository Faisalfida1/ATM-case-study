

public class Main {
    public static void main(String[] args) {
        atm1 theATM = new atm1();
        theATM.run();
    }
}